#include<iostream>
using namespace std;
int main(){
string name;
int age,num;
cout<<"Enter your name : "; 
cin>>name;
cout<<"Enter your age : "; 
cin>>age;
cout<<"Enter your num : "; 
cin>>num;
cout<<"Name that you entered :";
cout<<name<<endl;
cout<<"Age that you entered :";
cout<<age<<endl;
cout<<"Number that you entered :";
cout<<num<<endl;

}
