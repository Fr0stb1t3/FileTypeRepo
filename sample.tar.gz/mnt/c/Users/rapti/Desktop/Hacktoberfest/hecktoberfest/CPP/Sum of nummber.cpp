#include<iostream>
using namespace std;
int main(){
int n,m;
cout<<"Enter your number : "; 
cin>>n;
  cout<<"Enter your number : "; 
cin>>m;
cout<<"Sum : ";
cout<<n+m;
}
